import 'package:flutter/material.dart';
import 'dart:math';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<String> _phrases = [];
  String? _selectedPhrase;

  void _showAddPhraseDialog() {
    final TextEditingController _dialogController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Adicionar Frase'),
          content: TextField(
            controller: _dialogController,
            decoration: InputDecoration(
              hintText: 'Digite uma nova frase',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                if (_dialogController.text.isNotEmpty) {
                  setState(() {
                    _phrases.add(_dialogController.text);
                  });
                  Navigator.of(context).pop();
                }
              },
              child: Text('Adicionar'),
            ),
          ],
        );
      },
    );
  }

  void _drawPhrase() {
    if (_phrases.isNotEmpty) {
      setState(() {
        _selectedPhrase = "A frase do dia é: ${_phrases[Random().nextInt(_phrases.length)]}";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Frases Motivacionais'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 5.0),
            child: IconButton(
              icon: Icon(Icons.add),
              onPressed: _showAddPhraseDialog,
            ),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: _drawPhrase,
              child: Text('Sortear Frase'),
            ),
            SizedBox(height: 20),
            if (_selectedPhrase != null)
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  _selectedPhrase!,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 18,
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
