package com.example.fraeses

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
